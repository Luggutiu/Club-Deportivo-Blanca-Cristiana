# En app/utils/__init__.py (o crea ese archivo si no existe)
def check_admin_logged(request):
    return True  # Permitir por ahora